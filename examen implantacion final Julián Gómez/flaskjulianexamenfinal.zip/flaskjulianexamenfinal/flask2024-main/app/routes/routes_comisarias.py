import random
from flask import Flask, Blueprint, render_template, request, redirect, url_for

from app import db

from app.data.comisarias_dao import comisariasDao




rutas_comisarias = Blueprint("routes_comisarias", __name__)


@rutas_comisarias.route('/delComisarias', methods=['POST'])   
def delComisarias():
    id = request.form['id']
    comisaria_dao = comisariasDao()
    comisaria_dao.delete(db,id)
   
    return redirect(url_for('routes.verComisarias'))  



@rutas_comisarias.route('/verComisarias', methods=['POST','GET'])   
def verComisarias():
    detenidos = list()
    nombreComisaria = ""
    comisarias_dao = comisariasDao()
    comisarias = comisarias_dao.select_all(db)
    
    return render_template('comisarias.html',comisarias=comisarias)

    if (request.method == 'POST'):
        id = request.form['id']
        detenidos_dao = detenidosDao()
        detenidos = detenidosDao.select_all(db,id)
        for detenido in detenidos:
            
            if (id == int(id.id)):
               
                nombreComisaria = Comisarias.nombre



    return render_template('comisarias.html',
                           detenidos=detenidos,
                           comisarias=comisarias,
                           nombreComisaria = nombreComisaria)