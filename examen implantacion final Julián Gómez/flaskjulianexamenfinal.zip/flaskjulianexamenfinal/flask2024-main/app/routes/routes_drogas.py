import random
from flask import Flask, Blueprint, render_template, request, redirect, url_for

from app import db
from app.data.comisarias_dao import Comisarias
from app.data.detenidos_dao import detenidosDao
from app.data.drogas_dao import DrogasDao



rutas_drogas = Blueprint("routes_drogas", __name__)


@rutas_drogas.route('/')
def index():
    return render_template('index.html')



@rutas_drogas.route('/verDrogas')
def verDrogas():
    drogas = list()
    drogas_dao = DrogasDao()
    drogas = drogas_dao.select_all(db)

    if (request.method == 'POST'):
        id = request.form['drogas']
        drogas_dao = DrogasDao()
        drogas = DrogasDao.select_all(db,id)


    return render_template('drogas.html',
                           drogas=drogas
                           )
    

  

@rutas_drogas.route('/delDrogas', methods=['POST'])   
def delDrogas():
    drogas_dao = DrogasDao()

    id = request.form['id']



    drogas_dao.delete(db,id)
   
    return redirect(url_for('routes.verDrogas'))    




