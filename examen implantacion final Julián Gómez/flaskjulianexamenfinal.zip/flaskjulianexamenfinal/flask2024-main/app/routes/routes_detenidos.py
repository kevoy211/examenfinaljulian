import random
from flask import Flask, Blueprint, render_template, request, redirect, url_for

from app import db
from app.data.comisarias_dao import comisariasDao
from app.data.detenidos_dao import detenidosDao


rutas_detenidos = Blueprint("routes_detenidos", __name__)


@rutas_detenidos.route('/')
def index():
    return render_template('index.html')

@rutas_detenidos.route('/nueva')
def nueva():
    loquequiera=random.randint(1,100)
    loquequiera2=random.randint(1,100)


    return render_template('nueva.html',aleatorio1=loquequiera,aleatorio2=loquequiera2)



@rutas_detenidos.route('/verDetenidos')
def verDetenidos():
    detenidos = ()
    comisarias_dao = comisariasDao()
    comisarias = comisarias_dao.select_all(db)

    if (request.method == 'POST'):
        id = request.form['detenidos']
        detenidos_dao = detenidosDao()
        detenidos = detenidos_dao.select_all(db,id)


    return render_template('detenidos.html',
                           detenidos=detenidos,
                           comisarias=comisarias
                           )
    




@rutas_detenidos.route('/addDetenidos', methods=['POST'])   
def addDetenidos():
    detenidos_dao = detenidosDao()

    nombre = request.form['nombre']
    edad = request.form['edad']
    id_comisaria = request.form['id_comisaria']
    id_droga = request.form ['id_droga']

    if (nombre == "" or edad == "" or id_comisaria == "" or id_droga == ""):
        return redirect(url_for('routes.verDetenidos'))
    else:
        detenidos_dao.insert(db,nombre,edad,id_comisaria,id_droga)
   
    #return render_template('ok.html')  
  
    return redirect(url_for('routes.verDetenidos'))    

@rutas_detenidos.route('/delDetenidos', methods=['POST'])   
def delDetenidos():
    detenido_dao = detenidosDao()

    id = request.form['id']



    detenido_dao.delete(db,id)
   
    return redirect(url_for('routes.verDetenidos'))    

@rutas_detenidos.route('/updateDetenidos', methods=['POST'])   
def updateDetenidos():
    detenido_dao = detenidosDao()

    nombre = request.form['nombre']
    edad = request.form['edad']
    id_comisaria = request.form['id_comisaria']
    id_droga = request.form ['id_droga']


    if (edad == ""):
        detenido_dao.updateNombre(db,id,nombre)
    else:
        detenido_dao.update(db,id,nombre,edad)
   
    return redirect(url_for('routes.verDetenidos'))    


