
from app.data.modelo.detenidos import Detenidos

class detenidosDao:

    def select_all(self,db,id_equipo) -> list[Detenidos]:
        cursor = db.cursor()
        cursor.execute(
        [id_equipo])
        detenidos_en_db = cursor.fetchall()
        detenidos : list[Detenidos]= list()
        for detenido_en_db in detenidos_en_db:
            detenidos.append(Detenidos(detenido_en_db[0], detenido_en_db[1], detenido_en_db[4],detenido_en_db[5],detenido_en_db[6]))

        cursor.close()
        return detenidos
    
    def select_uno(self,db,nombre) -> Detenidos:
        cursor = db.cursor()
        cursor.execute('SELECT * FROM comisarias where nombre = %s',[nombre])
        detenidos_en_db = cursor.fetchall()
        if (detenidos_en_db == []):
            return None
        detenido_en_db = detenidos_en_db[0]        
        detenido = Detenidos(detenido_en_db[0], detenido_en_db[1], detenido_en_db[4],detenido_en_db[5],detenido_en_db[6])
        cursor.close()
        return detenido

    def insert(self,db,nombre,edad,id_comisaria,id_droga):
        cursor = db.cursor()
        sql = ("INSERT INTO detenidos (nombre,edad,id_comisaria,id_droga) values (%s,%s,%s,%s) ")
        data = (nombre,edad,id_comisaria,id_droga)
        cursor.execute(sql,data)
        db.commit()

    def delete(self,db,id):
        cursor = db.cursor()
        sql = ("delete from detenidos where id = %s ")
        data = [id]
        cursor.execute(sql, data)
        db.commit()
        
    def update(self,db,id,nombre,edad,id_comisaria,id_droga):
        cursor = db.cursor()
        sql = ("update detenidos set nombre = %s, edad = %s, id_comisaria = %s, id_droga where id = %s ")
        data = [nombre,edad,id_comisaria,id_droga,id]
        cursor.execute(sql, data)
        db.commit()   
           
    def updateNombre(self,db,id,nombre):
        cursor = db.cursor()
        sql = ("update detenidos set nombre = %s where id = %s ")
        data = [nombre,id]
        cursor.execute(sql, data)
        db.commit()           