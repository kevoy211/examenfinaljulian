--- 
title: Examennotas
---
<h1>notas del curso</h1>

<table>
    <thead>
        <tr>nombre</tr>
        <tr>notas</tr>
        <tr>sexo</tr>
    </thead>
    <tbody>
      {% for nota in data.post.notas %}
        <tr>
            <td>{{nota.nombre}}</td>
            <td>{{nota.notas}}</td>
            <td>{{nota.sexo}}</td>
        </tr>
      {% endfor %}
    </tbody>
</table>