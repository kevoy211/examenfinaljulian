

class Drogas:
    def __init__(self, id : int,nombre : str,):
        self.id = id
        self.nombre = nombre

        
