class Detenidos:

   def __init__(self, id : int,nombre : str, edad:int, id_comisaria:int, id_droga:int):
        self.id = id
        self.nombre = nombre
        self.edad = edad
        self.id_comisaria = id_comisaria 
        self.id_droga = id_droga
        