

class Comisarias:
    def __init__(self, id : int,nombre : str, direccion:str):
        self.id = id
        self.nombre = nombre
        self.direccion = direccion
        
