
from app.data.modelo.drogas import Drogas

class DrogasDao:

    def select_all(self,db) -> list[Drogas]:
        cursor = db.cursor()
        cursor.execute('SELECT * FROM drogas')
        drogas_en_db = cursor.fetchall()
        drogas : list[Drogas]= list()
        for droga in drogas_en_db:
            drogas.append(Drogas(droga[0], droga[1]))

        cursor.close()
        return droga
    
    def select_uno(self,db,nombre) -> Drogas:
        cursor = db.cursor()
        cursor.execute('SELECT * FROM drogas where nombre = %s',[nombre])
        drogas_en_db = cursor.fetchall()
        if (drogas_en_db == []):
            return None
        droga_en_db = drogas_en_db[0]        
        droga = Drogas(droga_en_db[0], droga_en_db[1],)
        cursor.close()
        return droga

   
    def delete(self,db,id):
        cursor = db.cursor()
        sql = ("delete from drogas where id = %s ")
        data = [id]
        cursor.execute(sql, data)
        db.commit()
        
    def update(self,db,id,nombre):
        cursor = db.cursor()
        sql = ("update drogas set nombre = %s where id = %s ")
        data = [nombre,id]
        cursor.execute(sql, data)
        db.commit()   
           
    def updateNombre(self,db,id,nombre):
        cursor = db.cursor()
        sql = ("update drogas set nombre = %s where id = %s ")
        data = [nombre,id]
        cursor.execute(sql, data)
        db.commit()           