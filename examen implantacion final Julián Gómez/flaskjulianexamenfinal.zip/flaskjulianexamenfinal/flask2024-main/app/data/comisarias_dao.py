
from app.data.modelo.comisarias import Comisarias

class comisariasDao:

    def select_all(self,db) -> list[Comisarias]:
        cursor = db.cursor()
        cursor.execute('SELECT * FROM comisarias')
        comisarias_en_db = cursor.fetchall()
        comisarias : list[Comisarias]= list()
        for comisaria in comisarias_en_db:
            comisarias.append(Comisarias(comisaria[0], comisaria[1], comisaria[2]))

        cursor.close()
        return comisarias
    
    def select_uno(self,db,nombre) -> Comisarias:
        cursor = db.cursor()
        cursor.execute('SELECT * FROM comisarias where nombre = %s',[nombre])
        comisarias_en_db = cursor.fetchall()
        if (comisarias_en_db == []):
            return None
        comisaria_en_db = comisarias_en_db[0]        
        comisaria = Comisarias(comisaria_en_db[0], comisaria_en_db[1], comisaria_en_db[2])
        cursor.close()
        return comisaria

    def insert(self,db,nombre,direccion):
        cursor = db.cursor()
        sql = ("INSERT INTO comisarias (nombre,direccion) values (%s,%s) ")
        data = (nombre,direccion)
        cursor.execute(sql,data)
        db.commit()

    def delete(self,db,id):
        cursor = db.cursor()
        sql = ("delete from comisarias where id = %s ")
        data = [id]
        cursor.execute(sql, data)
        db.commit()
        
    def update(self,db,id,nombre,direccion):
        cursor = db.cursor()
        sql = ("update comisarias set nombre = %s, direccion = %s where id = %s ")
        data = [nombre,direccion,id]
        cursor.execute(sql, data)
        db.commit()   
           
    def updateNombre(self,db,id,nombre):
        cursor = db.cursor()
        sql = ("update comisarias set nombre = %s where id = %s ")
        data = [nombre,id]
        cursor.execute(sql, data)
        db.commit()           