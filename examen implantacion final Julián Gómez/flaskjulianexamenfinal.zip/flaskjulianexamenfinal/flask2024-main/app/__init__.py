from flask import Flask

import mysql.connector 


# db = list()
db = mysql.connector.connect( # LLAMAMOS AL FUNCION CONNECT PARA CONECTARNOS
    host ='localhost',
    port = 6033,
    ssl_disabled = True,
    user ='root', #USUARIO QUE USAMOS NOSOTROS
    password ='julian', #CONTRASEÑA CON LA QUE NOS CONECTAMOS
    database='oscar'
) 



def create_app():
    app = Flask(__name__)
    app.debug = True
    

    

    from .routes import routes_detenidos
    from .routes import routes_comisarias
    from .routes import routes_drogas
    
    app.register_blueprint(routes_detenidos.rutas_detenidos)
    app.register_blueprint(routes_comisarias.rutas_comisarias)
    app.register_blueprint(routes_drogas.rutas_drogas)


    return app
