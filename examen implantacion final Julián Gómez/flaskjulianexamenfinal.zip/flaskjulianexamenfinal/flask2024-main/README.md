## flask2024

- uno
- dos

cambio desde local  

cambio de Juan desde casa

cambio Jorge desde la empresa

otro cambio LA MISMA LINEA OSCAR
otro cambio LA MISMA LINEA JUAN

> hola
> > tu

\>
[ver el periodico](http://www.as.com)
